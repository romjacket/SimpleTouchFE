 
SimpleTouch FE v1.16
____________________________________________________________________

Written by Lars Lindg�rd
July 2019
lars.lindgard@gmail.com

If you use this program I would appreciate if you send me an E-mail.
Just so I can get an overview of how many people who are actually using it.

Donations are also welcome.  Use this link: 

https://tinyurl.com/y3bg9sca 

or click on the link in the about-page in the config program.


NB!!
The program was designed to run on Windows XP.
I will, for the most part, work on later versions of Windows as well.
However, on later Windows-versions, it should be installed to a different folder than "c:\Program Files" or "C:\Program Files (x86)".
E.g "c:\STFE", "C:\Programs\STFE" or something similar.
This because, starting with Windows Vista, Microsoft has made the "Program Files/Program Files (x86)" special folders, 
disalowing write-access to the folders within.
STFE relies heavliy on writing ini-files, and this is not possible in Windows versions after XP without 
messing around with ownership and permissions.


Quickstart : 
____________

Start FEConfig.exe to add games/programs.

Adding games:
-------------

Drag and drop:
-------------
* Drag and drop exe-files, batch-files or shortcuts to add games to the selected config.
* Drag and drop image-files to add images to the selected game.  Right click image to remove it.

Manual:
-------
* Click the add-button and type in the display-name for the game.
* Select the exe-file you want to run when you click the image in the FE.
* Write in optional parameters used by the exe-file.
* Click the image to locate images to display. Right click image to remove it.

Autoinsert:
-----------
* You can also use the "Autoinsert games" function which will try to add programs/games automatically.
* See the "Autoinsert games" tab in the config-program for instructions.


The config will autosave after each change you do.


Skinning : 
__________

To skin the FE start the program with the parameter "skinmode" or start the included batch-file.
All images can contain images of the supported image formats: BMP, PNG, JPG, GIF (including animated GIFs)
The images not found will be ignored and the image will be cleared.

Once in skinmode you can drag and resize the components as you see fit, or you can type in the 
values in the edit-boxes. The program will remember the last edit-box that was clicked and highlight that for each component you click
until you click another edit-box.
Pressing the close-button before saving will discard all changes.
To get back to the default settings, just delete the skin.ini file.

Background/overlay images:
The background/overlay images is normally located in the <skin> folder. The first image found will be used. E.g. if you have a file called 
"Background.gif" and one called "Background.png" the file "Background.gif" will be used. 
Different background images can be used for each of the config pages.  Just put the wanted image in the "<skin>\PageImages\<Config#>" folder and
name it "background" e.g. "background.png", "background.gif" etc, etc. 
The same goes for the overlay image.
If a background/overlay image is not found in the "<skin>\PageImages\<Config#>" folder it will use the one located in the <skin> folder. 
If you don't want to use the overlay for one particular page just copy the "transparent.png" file, located in the <skin> folder, 
to that folder and rename it to "overlay.png".  
If you don't want to use an overlay you can delete the "overlay.png" image.
The overlay image should of course be transparent to be able to see the background image below. I recommend using a PNG image for this.

Control images:
To change the control images put the desired images in the skin folder with the appropriate names (Backward, Forward and PowerOff).  
The first image found will be used. E.g if you have a file called "Forward.gif" and one called "Forward.png" the file "Forward.gif" will be used. 
To enable animation of the control images put an ekstra file in the skin folder - named BackwardDown, ForwardDown and PowerOffDown.
This is the image used when the control is pressed "down".  You set the delay for the animation in the config program.
You can have different control images for each of the configs.  If none is found in the "<skin>\PageImages\<Config#>" folder the ones in the <skin> 
folder will be used.

Page images: 
Page images are placed in the "<skin>\PageImages\<Config#>" folder. They must be called the same number as the page they represent.
E.g. Page #1 image must be called "1.<ImageFormat>"

Pincode images: 
Pincode images are placed in the "<skin>\PincodeImages\" folder.
It's not possible to change the size of the pincode screen. It's size is set to 222 x 367 pixels, as is the background image.
Each of the number images can be up to  74 x 74 pixels.
The size of the display image is  222 x 74 pixels.
The enter image is 148 x 74 pixels.
If you prefer, you can ignore the display image and incorporate the pincode entry display in the background image.
All images will be centered if smaller than the stated size.

Shutdown images: 
Shutdown images are placed in the "<skin>\ShutdownImages\" folder.
It's not possible to change the size of the shutdown screen. It's size is set to 160 x 280 pixels, as is the background image.
Each of the shutdown images can be up to  160 x 55 pixels.
All images will be centered if smaller than the stated size.

Config images:
The config images is used when selecting a different configuration.
The images in the "<skin>\ConfigImages\Active" folder is used when a config is selected.
The images in the "inactive" folder is used when deselected.
If you prefer you can delete the files in the inactive folder and incorporate the inactive image in the background image.

Sounds:
To change the sounds used by the program change the wav-files in the "<skin>\Sounds" folder.

Preview image:
If you create a skin put an image named "Preview" (any of the supported image formats) in the root of your skin folder. This will then
be used as the preview image in the config program.

Resize:
To resize a skin simply copy the skin to be resized to a new folder.  Then open feconfig.exe and select the new skin.
Start STFE in skinmode.  Set the new size and press the resize button. Note the new sizes for the components. Save and exit.
Open up your image editor and resize the images to the new sizes noted in edit mode.  This will make the skin look much nicer than
using the "on the fly" resizing, as a dedicated image editor will resize the images with much better quality than STFE.
From version 1.12 of the program it's also possible to create a batch-file that will resize all images to the correct size with the use 
of ImageMagick. This is a freeware program available at: http://www.imagemagick.org/script/binary-releases.php#windows


Other functions:
________________

The killprogram-function works in the following way:
Set the area that is checked for mouseclicks.
If the number of clicks required (clicks to close) to close the program is not reached within the set delay (reset clicks delay), the click counter 
will reset to zero.
When the function tries to close the program it will first try to close it gracefully.  If the process is still active after the set delay (kill after) 
the process will be terminated.


ACKNOWLEDGEMENTS
____________________________________________________________________

This program was developed with the use of CodeGear Delphi 2007 and uses the following components :

Various components from the project JEDI's JVCL at http://jvcl.sourceforge.net
SelectOnRunTime, written by Germ�n Est�vez at http://neftali.clubdelphi.com/mainen.html
TPicShow, written by Kambiz R. Khojasteh at http://delphiarea.com/products/picshow/
Bass.dll from un4seen developments at http://www.un4seen.com/
DsPack at http://www.progdigy.com/
LowLevelMouseHook by Igor Zorkov


LICENSING AND DISTRIBUTION
____________________________________________________________________

"SimpleTouch FE" is free software. You can use it without charge for
private use only. Commercial use is strictly prohibited.
The program is provided "as is", without warranty of any kind, 
express or implied. The author shall not be liable for any damages 
caused by the use of or inability to use this program. This means 
that the user must assume the entire risk of using this program.

Use of this software indicates you understand and agree to the 
conditions of this license agreement.

You may copy this software as you wish, give exact copies of 
the original version to anyone, and distribute it via the internet
provided that:

1. The program itself or the original archive is not modified in 
   any way.

2. You do not charge or request donations for any such copies.

3. You do not distribute the program with other products without 
   the author's written permission.

4. You get permission from the author to publish on CD, DVD or BD.


Version history
____________________________________________________________________

V 1.16 (22.07.19)
------------------
* Fixed a bug where games with videos would load the wrong game after changing configs.

V 1.15 (16.04.11)
------------------
* Fixed a bug where games with videos would load the game from the first page.
* Added option to quit the FE from one of the game images by setting "-quit" as the executable.

V 1.14 (10.03.11)
------------------
* Added code to prevent several games to load in succession if more than one image was clicked.
* Added support for optional keyboard navigation.
* Added preliminary support for flash videos (swf).
* Fixed some small bugs that I can't remember


V 1.13 (22.08.10)
------------------
* Fixed a bug that would delete game.inis when delete button was pressed. Regardless of what had focus.
* Fixed a bug in the skinmode that would not load the different skins for the configs.
* Added option to hide desktop icons.
* Added option to run a second program before each game/program.
* Added selectable alignment of the various fonts.
* Added option to customize the Mp3 info


V 1.12 (30.12.09)
------------------
* Added option to have up to 99 snapshots per page and up to 99 different configs.
* Added function to start a program with mouseclick/hotkey after program launch.
* Added option to create batch-file for resize of skin-images with ImageMagick.
* Added option to save screenshots as PNG.
* Added hints to some of the config options.
* Changed the function to kill program with mouseclick/hotkey. 
  It's now possible to place the "kill/start-area" over the whole screen. Not just the upper left corner.
* Changed the kill/start function to be enabled on a per game basis.  
* Fixed the resize code to properly resize to all resolutions.
* Improved the skin mode.


V 1.11 (02.12.09)
------------------
* Changed the code that launches the programs.
* Added an alternative way to launch programs.
* Changed the "unload images when launching game" option.
* Rearranged the options a bit in the config program.


V 1.10 (22.11.09)
------------------
* Fixed a bug in loading of the background image when using a different background-image/skin for config01.
* Fixed a bug with delayed shutdown of the FE.
* Fixed a bug with the uninstaller not removing the shortcuts from the start menu in Windows Vista.
* Added functionality to add games from shortcuts, batch-files and exe-files with drag and drop.  
* Added functionality to add videos & images with drag and drop.


V 1.09 (24.05.09)
------------------
* Fixed a bug that could cause FeConfig to hang when using the autoinsert feature.
* Modified the autoinsert code slightly to get better display names.


V 1.08 (20.05.09)
------------------
* Changed the game ini-files to use names based on display name rather than the generic Game0001, Game0002 etc.
* Changed the way screenshots are taken. They are now stored in a folder called "snapshots" in the FE folder.
* Added click-animation to the pincode-screen.
* Added transparancy to the pincode-screen and the shutdown screen.
* Added optional transition effects when changing configs. (Only useful with a nested skin).
* Added a back button to traverse configs. (Only useful with a nested skin).
* Added option to copy screenshots to the snapshots folder when assigning the screenshot.
* Added option to resize screenshots in the copy-process.
* Added option to rename ini-files to the same as the display name directly from the config program.
* Removed the sort-button as it's no longer needed.


V 1.07 (22.02.09)
------------------
* Fixed an "Access violation" error on loading of some PNG-files.
* Fixed an "Access violation" error that would occur on startup if there was a video on the first page.
* Fixed an "The operation cannot be performed because the pins are not connected" error on loading of some video files.
* Fixed a bug that could cause the info for one of the programs to be cleared.
* Added an option to chose whether to use/create a music.m3u file.
* Added code to loop the MP3 if only one is found. Useful for setting an ambience sound for the FE.


V 1.06 (03.02.09)
------------------
* Added an option to not wait for the launched program to finish.
* Added a function to sort the game by their description.
* Added a new function to close the launched program with a mouseclick-pattern.


V 1.05 (01.10.08)
------------------
* Added an option to set sample rate for the sound.
* Added an option to disable sound all together.
* Added an option to quit, shutdown etc. by userdefined keypress.
* Added an option to disable the poweroff image.
* Added an optional Mp3 info label to show current playing song.
* Added an optional image to select next Mp3.
* Added an option to kill hung programs (If that should ever happen).


V 1.04 (31.08.08)
------------------
* Fixed a bug in the display of video files.
* Fixed a bug in the auto-insert games function.
* Fixed a bug in the changing of configs in the FE.
* Added an option to take screenshots of the games and resize them to user defined size.
* Added code to copy multiple games between configs.
* Added code to delete multiple games from configs.
* Added code to reset screen resoulution back to standard after a game.
* Added an optional poweroff screen with quit, shutdown, reboot, standby and hibernate.


V 1.03 (20.08.08)
------------------
* Fixed a bug where the game labels would be incorret if no image was assigned to the game.
* Added a dropdown box to the skin mode for selection of which page to skin.
* Added support for a second image to display when launching a game.
* Added an option to testrun a game from the config program.
* Added option to delete games from the config program.
* Changed the code for how the display of background, overlay and control images works.
* Changed the background music to use a folder rather than a single file.
* Changed the name of the gamefiles.  Run the included "AddZeroFix.exe" to convert old gamefiles.


V 1.02 (14.08.08)
------------------
* Fixed a bug when displaying animated gifs.  It would consume far to much CPU.
* Added code for autoinsertion of games to the config program.
* Added support for video-previews. 
* Added support for individual skins for each config-page.
* Added optional window-animation.


V 1.01 (08.08.08)
------------------
* Added an extra optional overlay image to the background.
* Added an option to have a background image/overlay image for each config.
* Added an optional config display name label.
* Added a resize option to the skin mode.


V 1.00 (05.08.08)
------------------
* Added transition/animation effects to the images when pageing backward and forward.
* Added a dummy.png file to the skin. For use with the transition effect.
* Added an extra imagefile for the forward, backward and poweroff images to create click animation.
* Moved some things around a bit in the config program.
* Changed the code to check for screensaver activity.  It now uses a timer with a user selectable delay.
* Changed the layout for the volume controls. (You will have to set the levels again initially).
* Created an installer for the program.


V 0.99 (03.08.08)
------------------
* Fixed a bug in the loading of the images. It would not clear the image if not found.
* Added support for entering a pincode on poweroff
* Added support for preview of the skins to the config program
* Added separate volume settings for the wav-files and mp3-files
* Added code to prevent STFE to react when the screensaver is active (Test. I couldn't reproduce this problem)
* Moved the sounds for the FX to the folder "<skin>\Sounds"
* Changed the name to SimpleTouch FE


V 0.98 (01.08.08)
------------------
* Fixed a bug where stfe.exe would take a lot of CPU-power after it launched a program.
* Added code so the the program uses the first image that matches the set filename. 
  E.g if you have a file called "Background.jpg" and one called "Background.png" the file "Background.jpg" will be used.
* Added animation effects to startup and poweroff


V 0.97 (01.08.08)
------------------
* Fixed the flickering problem.
* Added support for PNG-files.
* Added support for running a program on poweroff.
* Added an option to set a delay for shutting down the FE.
* Added an option to hide the poweroff image. (It can still be clicked,  but you will have to know the position of the image)
* Added a sound-effect to the change config event.
* Moved the numbers-folder away from the skin.
* Changed all control-images/hardcoded image names to use PNG-files instead of JPG.


V 0.96 (29.07.08)
------------------
* Fixed a bug in the drag and drop code.
* Added the option to select number of images and config-images to the skin mode.
* Added code to make the skin mode easier to use.
* Added an option to hide all labels.
* Moved the font setting to the skin.
* Changed the default skin to use animated gifs for the controls.


V 0.95 (28.07.08)
------------------
* Added the ability to have up to 10 different configs and choose between them by clicking an image in the FE.
* Added an option to display a page indicator label.
* Added an option to have a page indicator image.
* Added sound-effects to the backward, forward and game start events.
* Added the option to have a mp3-file play in the background while browsing the games.
* Added support for animated gif images. Both for the display images and the control images.
* Added support for dragging and dropping game config-files from one config to one of the other.
* Added code to prevent the user from clicking the images once a game is started.


V 0.9 (18.07.08)
------------------
* Initial Release
